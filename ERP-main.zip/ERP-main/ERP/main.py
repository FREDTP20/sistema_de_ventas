import tkinter as tk
from tkinter import messagebox

from PIL import Image, ImageTk

from config import *
from database import *

from modules.dashboard import DashboardFrame
from modules.inventario import InventarioFrame
from modules.clientes import ClientesFrame
from modules.proveedores import ProveedoresFrame
from modules.ventas import VentasFrame


class ERPApp:

    def __init__(self, root):

        self.root = root

        # ==========================================
        # CONFIGURACIÓN DE LA VENTANA
        # ==========================================

        self.root.title(APP_NAME)

        self.root.geometry("1366x768")

        self.root.configure(
            bg=COLOR_FONDO
        )

        # ==========================================
        # CREAR INTERFAZ
        # ==========================================

        self.crear_interfaz()

    # ==========================================
    # CREAR INTERFAZ
    # ==========================================

    def crear_interfaz(self):

        # ==========================================
        # SIDEBAR
        # ==========================================

        sidebar = tk.Frame(
            self.root,
            bg=COLOR_SECUNDARIO,
            width=220
        )

        sidebar.pack(
            side="left",
            fill="y"
        )

        sidebar.pack_propagate(False)

        # ==========================================
        # LOGO / TÍTULO
        # ==========================================

        tk.Label(
            sidebar,
            text="🛒 ERP EMPRESARIAL",
            bg=COLOR_SECUNDARIO,
            fg="white",
            font=("Segoe UI", 13, "bold")
        ).pack(
            pady=(20, 5)
        )

        tk.Label(
            sidebar,
            text="Versión 1.0",
            bg=COLOR_SECUNDARIO,
            fg="#94A3B8"
        ).pack(
            pady=(0, 15)
        )

        # ==========================================
        # MENÚ
        # ==========================================

        menus = [
            ("📊", "Dashboard"),
            ("🛒", "Ventas"),
            ("📦", "Inventario"),
            ("👥", "Clientes"),
            ("🚚", "Proveedores"),
            ("💰", "Cuentas por Cobrar"),
            ("💳", "Cuentas por Pagar"),
            ("📈", "Reportes"),
            ("🔍", "Auditoría"),
            ("🚪", "Cerrar Sesión"),
        ]

        for icono, opcion in menus:

            # ======================================
            # CERRAR SESIÓN
            # ======================================

            if opcion == "Cerrar Sesión":

                comando = self.cerrar_sesion

            # ======================================
            # DEMÁS OPCIONES
            # ======================================

            else:

                comando = lambda op=opcion: self.cargar_modulo(op)

            tk.Button(
                sidebar,
                text=f"  {icono}   {opcion}",
                bg=COLOR_SECUNDARIO,
                fg="white",
                relief="flat",
                anchor="w",
                padx=12,
                pady=7,
                font=("Segoe UI", 10),
                activebackground="#334155",
                activeforeground="white",
                cursor="hand2",
                command=comando
            ).pack(
                fill="x",
                pady=1
            )

        # ==========================================
        # FOOTER
        # ==========================================

        footer = tk.Frame(
            sidebar,
            bg="#0F172A"
        )

        footer.pack(
            side="bottom",
            fill="x"
        )

        tk.Label(
            footer,
            text=EMPRESA,
            bg="#0F172A",
            fg="white",
            font=("Segoe UI", 9, "bold")
        ).pack(
            anchor="w",
            padx=10,
            pady=(10, 2)
        )

        tk.Label(
            footer,
            text=f"NIT: {NIT}",
            bg="#0F172A",
            fg="#94A3B8",
            font=("Segoe UI", 8)
        ).pack(
            anchor="w",
            padx=10,
            pady=(0, 10)
        )

        # ==========================================
        # ÁREA CENTRAL
        # ==========================================

        self.workspace = tk.Frame(
            self.root,
            bg=COLOR_FONDO
        )

        self.workspace.pack(
            expand=True,
            fill="both"
        )

        # ==========================================
        # DASHBOARD INICIAL
        # ==========================================

        self.cargar_dashboard()

    # ==========================================
    # LIMPIAR WORKSPACE
    # ==========================================

    def limpiar_workspace(self):

        for widget in self.workspace.winfo_children():

            widget.destroy()

    # ==========================================
    # DASHBOARD
    # ==========================================

    def cargar_dashboard(self):

        self.limpiar_workspace()

        DashboardFrame(
            self.workspace
        ).pack(
            expand=True,
            fill="both"
        )

    # ==========================================
    # CARGAR MÓDULO
    # ==========================================

    def cargar_modulo(self, modulo):

        self.limpiar_workspace()

        # ======================================
        # DASHBOARD
        # ======================================

        if modulo == "Dashboard":

            DashboardFrame(
                self.workspace
            ).pack(
                expand=True,
                fill="both"
            )

        # ======================================
        # INVENTARIO
        # ======================================

        elif modulo == "Inventario":

            InventarioFrame(
                self.workspace
            ).pack(
                expand=True,
                fill="both"
            )

        # ======================================
        # CLIENTES
        # ======================================

        elif modulo == "Clientes":

            ClientesFrame(
                self.workspace
            ).pack(
                expand=True,
                fill="both"
            )

        # ======================================
        # PROVEEDORES
        # ======================================

        elif modulo == "Proveedores":

            ProveedoresFrame(
                self.workspace
            ).pack(
                expand=True,
                fill="both"
            )

        # ======================================
        # VENTAS
        # ======================================

        elif modulo == "Ventas":

            VentasFrame(
                self.workspace
            ).pack(
                expand=True,
                fill="both"
            )

        # ======================================
        # MÓDULOS EN CONSTRUCCIÓN
        # ======================================

        else:

            tk.Label(
                self.workspace,
                text=f"Módulo {modulo} en construcción",
                font=("Segoe UI", 18, "bold"),
                bg=COLOR_FONDO,
                fg="#0F172A"
            ).pack(
                pady=100
            )

    # ==========================================
    # CERRAR SESIÓN
    # ==========================================

    def cerrar_sesion(self):

        respuesta = messagebox.askyesno(
            "Cerrar sesión",
            "¿Está seguro de que desea cerrar sesión?"
        )

        if respuesta:

            self.root.destroy()


# ==============================================
# INICIO DEL SISTEMA
# ==============================================

if __name__ == "__main__":

    # ==========================================
    # CREAR TABLAS
    # ==========================================

    crear_tablas()

    insertar_productos_prueba()

    # ==========================================
    # CREAR VENTANA
    # ==========================================

    root = tk.Tk()

    # ==========================================
    # CARGAR ICONO DESDE ASSETS
    # ==========================================

    try:

        imagen_logo = Image.open(
            ICON_PATH
        )

        # Tomar el primer frame del ICO
        imagen_logo.seek(0)

        # Convertir a RGBA
        imagen_logo = imagen_logo.convert(
            "RGBA"
        )

        # Crear imagen compatible con Tkinter
        icono_tk = ImageTk.PhotoImage(
            imagen_logo
        )

        # Aplicar icono a la ventana
        root.iconphoto(
            True,
            icono_tk
        )

        # Conservar la referencia
        root.icono_logo = icono_tk

    except Exception:

        pass

    # ==========================================
    # CREAR APLICACIÓN
    # ==========================================

    app = ERPApp(
        root
    )

    # ==========================================
    # EJECUTAR
    # ==========================================

    root.mainloop()