import tkinter as tk
from tkinter import messagebox

from config import (
    COLOR_FONDO
)

from database import (
    total_productos,
    total_clientes,
    total_proveedores,
    total_ventas
)


class DashboardFrame(tk.Frame):

    def __init__(self, parent):

        super().__init__(
            parent,
            bg=COLOR_FONDO
        )

        self.crear_dashboard()

    # ==========================================
    # CREAR TARJETA
    # ==========================================

    def crear_tarjeta(
        self,
        parent,
        titulo,
        valor,
        color
    ):

        card = tk.Frame(
            parent,
            bg=color,
            width=220,
            height=120
        )

        # Mantener tamaño de la tarjeta
        card.pack_propagate(False)

        # Título
        tk.Label(
            card,
            text=titulo,
            bg=color,
            fg="white",
            font=("Segoe UI", 11, "bold")
        ).pack(
            pady=(20, 5)
        )

        # Valor
        tk.Label(
            card,
            text=str(valor),
            bg=color,
            fg="white",
            font=("Segoe UI", 24, "bold")
        ).pack()

        return card

    # ==========================================
    # CREAR DASHBOARD
    # ==========================================

    def crear_dashboard(self):

        # --------------------------------------
        # TÍTULO
        # --------------------------------------

        titulo = tk.Label(
            self,
            text="DASHBOARD",
            bg=COLOR_FONDO,
            fg="#0F172A",
            font=("Segoe UI", 18, "bold")
        )

        titulo.pack(
            pady=(20, 10)
        )

        # --------------------------------------
        # CONTENEDOR DE TARJETAS
        # --------------------------------------

        tarjetas = tk.Frame(
            self,
            bg=COLOR_FONDO
        )

        tarjetas.pack(
            pady=15
        )

        # --------------------------------------
        # PRODUCTOS
        # --------------------------------------

        try:
            productos = total_productos()
        except Exception:
            productos = 0

        self.crear_tarjeta(
            tarjetas,
            "PRODUCTOS",
            productos,
            "#2563EB"
        ).pack(
            side="left",
            padx=10
        )

        # --------------------------------------
        # CLIENTES
        # --------------------------------------

        try:
            clientes = total_clientes()
        except Exception:
            clientes = 0

        self.crear_tarjeta(
            tarjetas,
            "CLIENTES",
            clientes,
            "#16A34A"
        ).pack(
            side="left",
            padx=10
        )

        # --------------------------------------
        # PROVEEDORES
        # --------------------------------------

        try:
            proveedores = total_proveedores()
        except Exception:
            proveedores = 0

        self.crear_tarjeta(
            tarjetas,
            "PROVEEDORES",
            proveedores,
            "#EA580C"
        ).pack(
            side="left",
            padx=10
        )

        # --------------------------------------
        # VENTAS
        # --------------------------------------

        try:
            ventas = total_ventas()
        except Exception:
            ventas = 0

        self.crear_tarjeta(
            tarjetas,
            "VENTAS",
            ventas,
            "#7C3AED"
        ).pack(
            side="left",
            padx=10
        )

        # --------------------------------------
        # MENSAJE DE BIENVENIDA
        # --------------------------------------

        tk.Label(
            self,
            text="Bienvenido al ERP Empresarial",
            bg=COLOR_FONDO,
            fg="#334155",
            font=("Segoe UI", 12)
        ).pack(
            pady=30
        )
