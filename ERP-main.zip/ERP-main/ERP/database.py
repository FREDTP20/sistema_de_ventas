import sqlite3
from config import DB_NAME


# =====================================================
# CONEXIÓN A LA BASE DE DATOS
# =====================================================

def conectar():
    return sqlite3.connect(DB_NAME)


# =====================================================
# CREAR TABLAS
# =====================================================

def crear_tablas():

    conn = conectar()
    cursor = conn.cursor()

    # =================================================
    # PRODUCTOS
    # =================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS productos(
            codigo TEXT PRIMARY KEY,
            nombre TEXT NOT NULL,
            precio REAL NOT NULL,
            stock INTEGER NOT NULL
        )
    """)

    # =================================================
    # CLIENTES
    # =================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS clientes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            tipo_documento TEXT,
            documento TEXT,
            telefono TEXT,
            direccion TEXT,
            sexo TEXT,
            email TEXT
        )
    """)

    # =================================================
    # PROVEEDORES
    # =================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS proveedores(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            nit TEXT,
            telefono TEXT,
            direccion TEXT
        )
    """)

    # =================================================
    # VENTAS
    # =================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ventas(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero_venta TEXT NOT NULL,
            fecha TEXT NOT NULL,
            vendedor TEXT NOT NULL,
            subtotal REAL NOT NULL,
            descuento REAL NOT NULL,
            iva REAL NOT NULL,
            total REAL NOT NULL,
            metodo_pago TEXT NOT NULL
        )
    """)

    # =================================================
    # DETALLE DE VENTA
    # =================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS detalle_venta(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            venta_id INTEGER NOT NULL,
            codigo_producto TEXT NOT NULL,
            producto TEXT NOT NULL,
            cantidad INTEGER NOT NULL,
            precio REAL NOT NULL,
            subtotal REAL NOT NULL,
            FOREIGN KEY (venta_id) REFERENCES ventas(id)
        )
    """)

    conn.commit()
    conn.close()


# =====================================================
# PRODUCTOS DE PRUEBA
# =====================================================

def insertar_productos_prueba():

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT COUNT(*)
        FROM productos
    """)

    cantidad = cursor.fetchone()[0]

    if cantidad == 0:

        productos = [
            ("1001", "Coca Cola 400ml", 3500, 150),
            ("1002", "Galletas Oreo", 4000, 50),
            ("1003", "Leche Alpina Entera", 5000, 70),
            ("1004", "Arroz Diana 500g", 2800, 120)
        ]

        cursor.executemany("""
            INSERT INTO productos(
                codigo,
                nombre,
                precio,
                stock
            )
            VALUES (?, ?, ?, ?)
        """, productos)

    conn.commit()
    conn.close()


# =====================================================
# OBTENER PRODUCTOS
# =====================================================

def obtener_productos():

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            codigo,
            nombre,
            precio,
            stock
        FROM productos
        ORDER BY nombre
    """)

    datos = cursor.fetchall()

    conn.close()

    return datos


# =====================================================
# BUSCAR PRODUCTO
# =====================================================

def buscar_producto(codigo):

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            codigo,
            nombre,
            precio,
            stock
        FROM productos
        WHERE codigo = ?
    """, (codigo,))

    producto = cursor.fetchone()

    conn.close()

    return producto


# =====================================================
# AGREGAR PRODUCTO
# =====================================================

def agregar_producto(codigo, nombre, precio, stock):

    conn = conectar()
    cursor = conn.cursor()

    try:

        cursor.execute("""
            INSERT INTO productos(
                codigo,
                nombre,
                precio,
                stock
            )
            VALUES (?, ?, ?, ?)
        """, (
            codigo,
            nombre,
            precio,
            stock
        ))

        conn.commit()

        return True

    except sqlite3.IntegrityError:

        return False

    finally:

        conn.close()


# =====================================================
# ACTUALIZAR PRODUCTO
# =====================================================

def actualizar_producto(
    codigo,
    nombre,
    precio,
    stock
):

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE productos
        SET
            nombre = ?,
            precio = ?,
            stock = ?
        WHERE codigo = ?
    """, (
        nombre,
        precio,
        stock,
        codigo
    ))

    actualizado = cursor.rowcount > 0

    conn.commit()
    conn.close()

    return actualizado


# =====================================================
# ELIMINAR PRODUCTO
# =====================================================

def eliminar_producto(codigo):

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        DELETE FROM productos
        WHERE codigo = ?
    """, (codigo,))

    eliminado = cursor.rowcount > 0

    conn.commit()
    conn.close()

    return eliminado


# =====================================================
# DESCONTAR STOCK
# =====================================================

def descontar_stock(codigo, cantidad):

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE productos
        SET stock = stock - ?
        WHERE codigo = ?
        AND stock >= ?
    """, (
        cantidad,
        codigo,
        cantidad
    ))

    actualizado = cursor.rowcount > 0

    conn.commit()
    conn.close()

    return actualizado


# =====================================================
# AUMENTAR STOCK
# =====================================================

def actualizar_stock(codigo, cantidad):

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE productos
        SET stock = stock + ?
        WHERE codigo = ?
    """, (
        cantidad,
        codigo
    ))

    actualizado = cursor.rowcount > 0

    conn.commit()
    conn.close()

    return actualizado


# =====================================================
# DASHBOARD
# =====================================================

def total_productos():

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT COUNT(*)
        FROM productos
    """)

    total = cursor.fetchone()[0]

    conn.close()

    return total


def total_clientes():

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT COUNT(*)
        FROM clientes
    """)

    total = cursor.fetchone()[0]

    conn.close()

    return total


def total_proveedores():

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT COUNT(*)
        FROM proveedores
    """)

    total = cursor.fetchone()[0]

    conn.close()

    return total


def total_ventas():

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT COUNT(*)
        FROM ventas
    """)

    total = cursor.fetchone()[0]

    conn.close()

    return total


# =====================================================
# REGISTRAR VENTA
# =====================================================

def registrar_venta(
    numero_venta,
    fecha,
    vendedor,
    subtotal,
    descuento,
    iva,
    total,
    metodo_pago
):

    conn = conectar()
    cursor = conn.cursor()

    try:

        cursor.execute("""
            INSERT INTO ventas(
                numero_venta,
                fecha,
                vendedor,
                subtotal,
                descuento,
                iva,
                total,
                metodo_pago
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            numero_venta,
            fecha,
            vendedor,
            subtotal,
            descuento,
            iva,
            total,
            metodo_pago
        ))

        venta_id = cursor.lastrowid

        conn.commit()

        return venta_id

    except Exception:

        conn.rollback()
        raise

    finally:

        conn.close()


# =====================================================
# REGISTRAR DETALLE DE VENTA
# =====================================================

def registrar_detalle(
    venta_id,
    codigo_producto,
    producto,
    cantidad,
    precio,
    subtotal
):

    conn = conectar()
    cursor = conn.cursor()

    try:

        cursor.execute("""
            INSERT INTO detalle_venta(
                venta_id,
                codigo_producto,
                producto,
                cantidad,
                precio,
                subtotal
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            venta_id,
            codigo_producto,
            producto,
            cantidad,
            precio,
            subtotal
        ))

        conn.commit()

        return True

    except Exception:

        conn.rollback()
        raise

    finally:

        conn.close()


# =====================================================
# OBTENER VENTAS
# =====================================================

def obtener_ventas():

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            id,
            numero_venta,
            fecha,
            vendedor,
            subtotal,
            descuento,
            iva,
            total,
            metodo_pago
        FROM ventas
        ORDER BY fecha DESC
    """)

    ventas = cursor.fetchall()

    conn.close()

    return ventas


# =====================================================
# OBTENER DETALLE DE VENTA
# =====================================================

def obtener_detalle_venta(venta_id):

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            id,
            venta_id,
            codigo_producto,
            producto,
            cantidad,
            precio,
            subtotal
        FROM detalle_venta
        WHERE venta_id = ?
    """, (venta_id,))

    detalle = cursor.fetchall()

    conn.close()

    return detalle


# =====================================================
# TOTAL DINERO EN VENTAS
# =====================================================

def total_ventas_dinero():

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT COALESCE(SUM(total), 0)
        FROM ventas
    """)

    total = cursor.fetchone()[0]

    conn.close()

    return total


# =====================================================
# PRODUCTOS CON BAJO STOCK
# =====================================================

def productos_bajo_stock(limite=10):

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            codigo,
            nombre,
            precio,
            stock
        FROM productos
        WHERE stock <= ?
        ORDER BY stock ASC
    """, (limite,))

    datos = cursor.fetchall()

    conn.close()

    return datos


# =====================================================
# REGISTRAR VENTA COMPLETA
# =====================================================

def registrar_venta_completa(
    numero_venta,
    fecha,
    vendedor,
    subtotal,
    descuento,
    iva,
    total,
    metodo_pago,
    carrito
):

    conexion = conectar()

    try:

        cursor = conexion.cursor()

        # =================================================
        # 1. GUARDAR CABECERA DE LA VENTA
        # =================================================

        cursor.execute("""
            INSERT INTO ventas(
                numero_venta,
                fecha,
                vendedor,
                subtotal,
                descuento,
                iva,
                total,
                metodo_pago
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            numero_venta,
            fecha,
            vendedor,
            subtotal,
            descuento,
            iva,
            total,
            metodo_pago
        ))

        venta_id = cursor.lastrowid

        # =================================================
        # 2. GUARDAR DETALLES
        # =================================================

        for item in carrito:

            codigo = item["codigo"]
            nombre = item["nombre"]
            cantidad = item["cantidad"]
            precio = item["precio"]
            subtotal_item = item["subtotal"]

            # ---------------------------------------------
            # VERIFICAR STOCK
            # ---------------------------------------------

            cursor.execute("""
                SELECT stock
                FROM productos
                WHERE codigo = ?
            """, (codigo,))

            resultado = cursor.fetchone()

            if not resultado:

                raise Exception(
                    f"El producto {codigo} ya no existe."
                )

            stock_actual = int(resultado[0])

            if stock_actual < cantidad:

                raise Exception(
                    f"Stock insuficiente para {nombre}.\n"
                    f"Disponible: {stock_actual}\n"
                    f"Solicitado: {cantidad}"
                )

            # ---------------------------------------------
            # GUARDAR DETALLE
            # ---------------------------------------------

            cursor.execute("""
                INSERT INTO detalle_venta(
                    venta_id,
                    codigo_producto,
                    producto,
                    cantidad,
                    precio,
                    subtotal
                )
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                venta_id,
                codigo,
                nombre,
                cantidad,
                precio,
                subtotal_item
            ))

            # ---------------------------------------------
            # DESCONTAR INVENTARIO
            # ---------------------------------------------

            cursor.execute("""
                UPDATE productos
                SET stock = stock - ?
                WHERE codigo = ?
            """, (
                cantidad,
                codigo
            ))

        # =================================================
        # 3. GUARDAR TODO
        # =================================================

        conexion.commit()

        return venta_id

    except Exception:

        conexion.rollback()

        raise

    finally:

        conexion.close()