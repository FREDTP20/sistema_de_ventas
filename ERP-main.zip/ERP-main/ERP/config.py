# ==============================
# CONFIGURACIÓN GENERAL ERP
# ==============================

import os


# ==============================
# INFORMACIÓN DE LA APLICACIÓN
# ==============================

APP_NAME = "ERP EMPRESARIAL"

EMPRESA = "Mi Empresa JURM S.A.S"

NIT = "900.123.456-7"


# ==============================
# RUTA PRINCIPAL DEL PROYECTO
# ==============================

BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)


# ==============================
# BASE DE DATOS
# ==============================

DB_NAME = os.path.join(
    BASE_DIR,
    "sistema_erp.db"
)


# ==============================
# CARPETA ASSETS
# ==============================

ASSETS_DIR = os.path.join(
    BASE_DIR,
    "assets"
)


# ==============================
# ICONO DE LA APLICACIÓN
# ==============================

ICON_PATH = os.path.join(
    ASSETS_DIR,
    "logo.ico"
)


# ==============================
# IMPUESTOS
# ==============================

IVA = 0.19


# ==============================
# COLORES
# ==============================

COLOR_PRIMARIO = "#2563EB"

COLOR_SECUNDARIO = "#1E293B"

COLOR_FONDO = "#F1F5F9"

COLOR_BLANCO = "#FFFFFF"

COLOR_EXITO = "#22C55E"